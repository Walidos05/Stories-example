// InstaStory.h

#import <React/RCTViewManager.h>

@interface InstaStory : RCTViewManager

@end
