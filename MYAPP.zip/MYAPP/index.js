import Story from "./src/Story";

export const InstaStory = Story;

export default InstaStory;
